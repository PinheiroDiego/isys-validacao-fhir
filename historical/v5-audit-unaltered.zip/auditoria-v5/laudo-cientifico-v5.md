# iSys — Auditoria da revalidação HL7 FHIR V5

Data do protocolo: 25/10/2026. Elaborado a partir do arquivo ZIP enviado e do pacote gerador V5, sem executar novo HL7 Validator.

## Estado e proveniência

- ZIP de execução oficial: SHA-256 `bf608b73f7a90a9411901803f5492a458c8a6204cd03e64414d5ebdcfc6f9d71`; 123,788 bytes.
- Manifesto V5: SHA-256 `f21f30fb4556aa2a95e13c4e708ad37cd80efffb743d3974c639b3b6654061e5`.
- Gold inalterado: SHA-256 `dec62b7e8e479270d447229946e8bbfd785e269a705be69b204b05766715ba94`.
- ZIP original da ontologia: SHA-256 `1784b46046ecbb38e3fa9e5259ff04aa50138226396040bfd85a89d42ce3d4e2`.
- Artefato V4 original: SHA-256 `73e01142b5e5ce00051aa33e7515b6ef8725615558d362905be3cf3cc7fa79e9`.
- Entradas conferidas com o pacote fonte: **42/42**; OperationOutcome conferidos com hashes da execução: **42/42**.
- Mudanças V5 vs V4: **12** entradas explicitamente corrigidas (F10_neutral, F12_neutral, F14_neutral, F16_neutral, F18_neutral, F20_neutral, F21_baseline, F22_baseline, F23_baseline, F24_baseline, F25_baseline, F26_baseline); **30** entradas iguais byte a byte.

## Execução oficial declarada e corroborada pelos logs

Validador CLI **7.0.3**, FHIR **4.0.1**, core `hl7.fhir.r4.core#4.0.1`, perfil-base `Bundle`, servidor externo de terminologias desativado (`-tx n/a`). O executável JAR não está no artefato; não foi possível recomputar seu hash localmente. A identificação da versão consta nos OperationOutcome/logs e na configuração fixada.

- **42/42** invocações com OperationOutcome; **5** erros no total, todos distribuídos pelos quatro controles estruturais F17–F20; **136** avisos acumulados.
- **12/12** referências sem erros; **12/12** controles semanticamente equivalentes sem erros; **8/8** alterações semânticas passaram sem erro de conformidade; **4/4** controles de defeito estrutural apresentaram erro; **6/6** representações vazias de recusa sem erro, mas **não são conversões**.
- Somatório dos tempos de invocação CLI: **644.942 s**; mediana por invocação **14.466 s**. Esse custo inclui inicializações e downloads/cache do ambiente, não o custo isolado da transformação ou das verificações semânticas.

## Matriz A/B/C

Condição A: **15/21 ocorrências convertidas (71,43%)**, **6 recusadas (28,57%)**, conforme manifesto; recusas mantidas separadas dos 36 itens B/C.

| Medida em 36 variantes | B — Validador HL7 | C — HL7 + comparador |
|---|---:|---:|
| VP | 4 | 12 |
| FN | 8 | 0 |
| FP | 0 | 0 |
| VN | 24 | 24 |
| Sensibilidade descritiva (VP / VP+FN) | 33.3% | 100.0% |
| Precisão descritiva (VP / VP+FP) | 100.0% | 100.0% |
| Alarmes em controles (FP / FP+VN) | 0.0% | 0.0% |

Das **8 mutações semânticas**, B identificou **0** e C identificou **8**, enquanto B detectou todos os **4 controles estruturais**. A ausência de FP se restringe a **24 controles/referências sintéticos** deliberadamente construídos; não atesta ausência de falsos alertas gerais.

## Casos mutados

| Família/variante | Erros HL7 | Avisos HL7 | Consultas Q01–Q05 diferentes |
|---|---:|---:|---|
| F09_mutation | 0 | 6 | Q01 |
| F10_mutation | 0 | 5 | Q01;Q02;Q03;Q04;Q05 |
| F11_mutation | 0 | 3 | Q01 |
| F12_mutation | 0 | 3 | Q03 |
| F13_mutation | 0 | 3 | Q02;Q04 |
| F14_mutation | 0 | 5 | Q02;Q04 |
| F15_mutation | 0 | 6 | Q01 |
| F16_mutation | 0 | 3 | Q02;Q04 |
| F17_mutation | 1 | 3 | — |
| F18_mutation | 1 | 5 | Q01;Q02;Q03;Q04;Q05 |
| F19_mutation | 1 | 3 | Q01 |
| F20_mutation | 2 | 3 | — |

## Interpretação

A versão V5 corrige os defeitos artificiais introduzidos pelo benchmark V4, com zero erros nos 12 controles equivalentes. Os oito cenários de perda/alteração de informação que são formalmente conformes passaram pelo validador. O comparador que utiliza a origem os identificou. Isto sustenta uma demonstração técnica do caráter insuficiente da conformidade FHIR para garantir equivalência semântica, **restrita ao benchmark sintético e às regras testadas**.

## Limitações indispensáveis para publicação

1. Esta é uma **replicação corretiva não cega** usando famílias anteriormente inspecionadas na V4. Não há novo holdout independente.
2. O gold e as mutações são assistidos por IA; falta adjudicação especializada independente.
3. Só foram exigidos recursos e perfis-base FHIR R4 (`Bundle`, com recursos internos); nenhuma prova de conformidade com guias nacionais ou validação clínica.
4. Com `-tx n/a`, não se realizou verificação externa de equivalência terminológica.
5. Existe dependência entre baseline, mutação e controle neutro em cada uma das 12 famílias; as 36 variantes não são observações independentes.
6. As verificações semânticas têm acesso à fonte sintética e à referência esperada; isso difere de um sistema que recebe exclusivamente o FHIR.
7. As 6 recusas são casos de cobertura da condição A, não controles positivos/negativos para as métricas B/C.
8. O oráculo não representa validação por profissional clínico ou especialista FHIR, e o tempo total do CLI não mede overhead semântico.

**Próxima etapa recomendada:** preservar a V5 como replicação corretiva documentada e preparar famílias inéditas independentes, com revisão do gold por especialista FHIR, inclusão de controles genuinamente difíceis e aferição separada do custo de C antes de uma comparação confirmatória.
