# iSys — V6.1 candidata pós-adjudicação G15/G35

**Estado:** decisão metodológica da especialista recebida; implementação e testes locais realizados; **ratificação das seis variantes novas pendente**; **HL7 Validator NÃO executado nesta V6.1**. Não divulgar como nova avaliação cega. A V6 original e a V5 estão preservadas nos arquivos históricos de hash imutável.

## Decisão incorporada

- G15 e G35: `Observation` sem valor, com `dataAbsentReason = unknown`, `status = unknown`; nenhum `valueQuantity` sem número, nenhum valor inventado.
- G35: unidade original `mg/dL` preservada em `Observation.note` com referência `G35-x1`. A mutação altera somente essa unidade textual para `g/L`. Não a tratar como normalização UCUM.
- G15: sua mutação inventa valor numérico 42, removendo `dataAbsentReason` para manter o FHIR estruturalmente consistente; não é uma mutação estrutural.
- G33/G34/G36 seguem como recusas do conjunto confirmatório; G09/G10 recusas do desenvolvimento.

## Contagens

| Etapa | Famílias | Conversíveis | Recusas | Entradas FHIR |
|---|---:|---:|---:|---:|
| Desenvolvimento | 10 | 8 | 2 | 26 |
| Confirmatório pós-revisão | 26 | 23 | 3 | 72 |
| Total | 36 | 31 | 5 | 98 |

Há 41 ocorrências sintéticas de exame; 36 são convertidas e cinco recusadas (**36/41; 87,80% de cobertura de engenharia**). Os casos dependentes dentro de uma família não constituem observações independentes.

## Protocolo do próximo passo

1. Solicitar apenas a **ratificação complementar dos casos G15/G35**, conforme `review/SOLICITACAO_RATIFICACAO.md`; a revisão anterior é preservada, com sua limitação de cegamento parcial.
2. Registrar a ratificação documental em `review/decisions.csv` e `review/attestation.json`, sem falsificar assinatura; o gate `src/review_gate.py` bloqueia a execução confirmatória enquanto pendente.
3. Enviar ao GitHub privado os arquivos desta V6.1 (não o ZIP de controle privado da pesquisadora). Executar `Actions → iSys V6.1 - HL7 Adjudicated Benchmark`, `scope=confirmatory`, **72 validações esperadas**, após o gate.
4. Recolher `isys-v6.1-confirmatory-hl7` e analisar `OperationOutcome` e métricas, sem apresentar V6.1 como confirmação totalmente cega.

A V6 candidata original tem 96 entradas (70 confirmatórias). Os valores de V6.1 **não substituem silenciosamente** os anteriores. O GitHub Actions nunca deve reutilizar resultados de V5/V6 como se fossem validação V6.1.

### Execução local (engenharia, sem HL7)

```bash
python3 src/verify_v6.py
python3 -m unittest discover -s tests -v
python3 src/review_gate.py   # BLOCKED enquanto pendente: esperado
```

## Limitações

FHIR R4 4.0.1 + perfis-base Bundle/Patient/Observation, validador CLI 7.0.3 fixado para a execução futura, `-tx n/a`, sem perfis nacionais nem afirmação de validação clínica. O *gold* foi originalmente elaborado com assistência de IA e revisado com ressalvas. A primeira revisão não foi totalmente cega. O G35/P,Q,R novo precisa ser ratificado; a especialista decidiu a regra, não validou o resultado de execução do algoritmo.
