# Solicitação de ratificação complementar — G15/G35

Prezada especialista,

Aplicamos a alternativa A indicada no seu parecer. Pedimos somente que confira as seis variantes G15 e G35 no pacote de revisão complementar (`G15` e `G35` × `baseline`, `neutral`, `mutation`), sem repetir a análise das outras 24 famílias.

**G15:** as variantes de referência/controle incluem `dataAbsentReason=unknown`, sem `value[x]`. A mutação adiciona `valueQuantity.value=42` e retira `dataAbsentReason` para não provocar erro estrutural intencionalmente, embora o valor não tenha respaldo na origem.

**G35:** referência/controle preservam exame, paciente, data e ausência do resultado; `Observation.note` registra a unidade textual original `mg/dL`, sem `valueQuantity`. Na mutação, apenas a unidade no `note` passa a `g/L`. Verifique se a diferença é uma **falha semântica** mesmo sem valor; não se exige codificação UCUM.

Solicitamos resposta objetiva: **(a)** ratifica G15/P,Q,R após alteração? **(b)** ratifica G35/P,Q,R como previsto, inclusive sua mutação? **(c)** mantém a ressalva de cegamento parcial e autoriza a menção anonimizada? Se houver discordância, indique o campo, a classificação correta e a justificativa. Uma resposta textual é suficiente; não é necessário assinar digitalmente nem preencher 66 linhas outra vez.

**Nota:** o material contém versões novas de dois casos anteriormente revisados. O primeiro parecer não pode ser descrito como revisão integralmente cega, nem as novas variantes como revisadas antes da sua resposta.
