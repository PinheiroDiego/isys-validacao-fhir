# Auditoria da revalidação oficial HL7 FHIR — V3

**Data de análise:** 25 de outubro de 2026.  
**Fonte primária:** ZIP de resultados do GitHub Actions, recebido do usuário.  
**Tipo de estudo:** piloto sintético e teste de engenharia; não validação clínica nem benchmark científico independente.

## 1. Conclusão verificada

A revalidação oficial foi concluída em 16/16 solicitações. O Bundle de referência passou de **17 erros em V2 para 0 erros em V3**, permanecendo com **13 avisos**. Também passaram sem erros os **2 Patient e 5 Observation** validados individualmente. Entre as oito mutações, **2 produziram erros oficiais** (duplicação de `fullUrl` e ausência de `Observation.status`); seis modificações de conteúdo passaram sem novos erros ou avisos.

Em contraste, o comparador com oráculo sintético, reexecutado nesta análise sobre os arquivos de entrada V3, sinalizou as **7/7 mutações classificadas como `SEMANTIC`**. O caso `remove_required_status` é um controle negativo formal capturado pelo HL7, não uma das sete mutações avaliadas pelo comparador semântico.

## 2. Ferramenta e integridade

- Validator CLI: **7.0.3**; hash SHA-256 do JAR: `57aa43fb40cec5de41def81c927725fd85908eeb71509b7f9313e04d9b8ec79b`.
- FHIR **4.0.1**; pacote esperado/carregado: `hl7.fhir.r4.core#4.0.1`; perfis-base `Patient`, `Observation`, `Bundle`.
- Terminologia externa desativada (`-tx n/a`). Logs confirmam carregamento das dependências HL7 adicionais, cujas versões estão disponíveis no log bruto.
- Java: **openjdk version "21.0.12.1" 2026-08-18 LTS**.
- Integridade de entradas: **16/16 hashes conferidos**; integridade das saídas: **16/16 hashes de OperationOutcome conferidos**.
- O hash do ZIP da ontologia permaneceu igual antes/depois: `1784b46046ecbb38e3fa9e5259ff04aa50138226396040bfd85a89d42ce3d4e2`.
- SHA-256 do ZIP de resultados recebido: `d4012e5bbfdf0a010b659b447037dee8a7d30e51c3f7fc72a9cea00ba6bc125f`.

## 3. Cobertura e qualidade formal

| Indicador | Resultado |
|---|---:|
| Solicitações oficiais concluídas | 16/16 (100%) |
| Execuções sem `error` ou `fatal` | 14/16 |
| `Bundle` base conforme | Sim (0 erros; 13 avisos) |
| `Patient` isolados sem erro | 2/2 |
| `Observation` isoladas sem erro | 5/5 |
| Ocorrências sintéticas convertidas | 5/11 (45,45%) |
| Ocorrências recusadas com justificativa | 6/11 (54,55%) |
| Total de erros nas 16 validações | 2 ocorrências de `issue` |
| Total de avisos nas 16 validações | 132 ocorrências de `issue` |
| Tempo somado dos processos Java | 236.37 s (inclui inicialização por execução) |

**Atenção:** um caso reprovado continua sendo uma validação oficial executada. Não confundir 100% de execução com 100% de conformidade dos 16 arquivos; a reprovação das mutações é desejada.

## 4. Comparação diferencial das mutações

| Mutação controlada | Erros V2 | Erros V3 | HL7 (B) | Oráculo (C) |
|---|---:|---:|---|---|
| Alteração de resultado numérico | 17 | 0 | Não detectou | Detectou |
| Troca de resultados entre exames | 17 | 0 | Não detectou | Detectou |
| Alteração de data do exame | 17 | 0 | Não detectou | Detectou |
| Reatribuição a outro paciente válido | 17 | 0 | Não detectou | Detectou |
| Remoção do resultado | 17 | 0 | Não detectou | Detectou |
| Inserção de valor sem suporte na origem | 17 | 0 | Não detectou | Detectou |
| Duplicação de entrada de Observation | 20 | 1 | Detectou | Detectou |
| Remoção de Observation.status (controle) | 18 | 1 | Detectou | Não se aplica |

**Diferencial:** B detectou 1/7 mutações do grupo `SEMANTIC` (a duplicação com `fullUrl` repetido), deixando 6/7 sem erro; o oráculo da condição C sinalizou 7/7. Como C inclui B, o controle `status` também é detectado pela composição B+C, mas não foi testado como mutação pelo oráculo semântico isolado. Em oito mutações totais, B detectou 2/8; B+C sinalizaria 8/8 no piloto. Não interpretar essas frações como sensibilidade populacional: são variantes dependentes construídas sobre uma base sintética.

### Causas específicas dos dois erros oficiais

- `duplicate_observation_entry`: invariável `bdl-7` — `Bundle.entry.fullUrl` repetida; isso não comprova detecção da duplicação semântica quando cada cópia possui identidade FHIR diferente.
- `remove_required_status`: cardinalidade obrigatória `Observation.status` (mínimo 1), erro estrutural de perfil-base.

## 5. Avisos (não são erros de conformidade)

- **71 ocorrências:** Constraint failed: dom-6: 'A resource should have narrative for robust management' (defined in http://hl7.org/fhir/StructureDefinition/DomainResource) (Best Practice Recommendation)
- **51 ocorrências:** Best Practice Recommendation: In general, all observations should have a performer
- **10 ocorrências:** Best Practice Recommendation: In general, all observations should have an effective[x] ()

No `Bundle` base, há 13 avisos: sete `dom-6` (recomendação de narrativa), cinco recomendações de `Observation.performer` e um aviso de `Observation.effective[x]` ausente. Não inventar autor ou data só para eliminar avisos; é preciso preservar a fonte e justificar as ausências. Os totais 132 e 2 contam mensagens repetidas entre validações, não casos independentes nem defeitos únicos.

## 6. Interpretação das condições experimentais

- **A — Conversão:** 5/11 ocorrências fictícias transformadas e 6/11 recusadas, com motivos registrados. Não confundir o subconjunto aceito com a cobertura total.
- **B — Validação FHIR:** a referência está formalmente conforme aos perfis-base; o HL7 capturou uma duplicação de fullUrl e a retirada de campo obrigatório, mas não as seis mutações semânticas que mantêm estrutura válida.
- **C — Validação FHIR + verificações semânticas:** a verificação reaplicada aos arquivos V3 confirmou sete alertas de sete mutações semânticas e nenhum alerta na base. É evidência de funcionamento em teste controlado, não comprovação de generalização nem taxa de falsos alarmes.

## 7. Limitações e próximos marcos científicos

1. O conjunto utiliza poucos indivíduos sintéticos e mutações derivadas da mesma fonte. A dependência entre variantes invalida inferências ingênuas de independência estatística.
2. Somente os perfis-base FHIR R4 foram testados. Não há validação contra perfis de implantação brasileiros nem contra terminologias em servidor externo.
3. Falso positivo e especificidade não estão medidos de modo defensável. Um baseline sem alerta é insuficiente para estimar comportamento de casos negativos variados.
4. A verificação semântica compara contra um oráculo separado do conversor, mas preparado para estes cenários; exige conjunto de avaliação cego e revisão especializada para o manuscrito.
5. A detecção da duplicação pelo HL7 decorreu de `fullUrl` duplicada: é necessário criar também duplicações de fato clínico com identificadores distintos.
6. Preservar as 16 saídas oficiais, manifests e logs brutos na versão do experimento; o presente laudo é derivado deles, não os substitui.
7. O pacote recebido não contém o prometido `differential-mutation-analysis.json`. Esta auditoria produziu a comparação externa e o arquivo `analise-derivada-v3.json`; não confundir esse arquivo com uma saída nativa do executor oficial.

## 8. Síntese aproveitável no manuscrito (após revisão da metodologia)

> Em um piloto sintético usando HL7 FHIR R4 4.0.1 e o validador oficial 7.0.3, os sete recursos individuais e o Bundle de referência passaram na validação pelos perfis-base, com avisos não bloqueantes. Entre sete mutações controladas de preservação, o validador sinalizou apenas a duplicação de uma entrada com `fullUrl` repetida, enquanto seis alterações de conteúdo mantiveram conformidade formal. Um comparador contra expectativas sintéticas separadas sinalizou as sete mutações. Esses resultados demonstram a viabilidade técnica da verificação adicional nos cenários testados, sem demonstrar generalização para outros dados, perfis ou ambientes clínicos.

_Registro: somente dados fictícios. Nenhuma validação clínica é reivindicada._
