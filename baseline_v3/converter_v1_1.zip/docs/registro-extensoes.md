# Registro versionado de extensões — iSys FHIR semantic preservation

**Versão:** teste-v1 (25/10/2026). **Não modifica a ontologia original.**

## Linha de base verificável

- Arquivo original exigido: `ontologia-cbms-ontologies.owx.zip`, contendo `ontologia-cbms-ontologies-owx-REVISION-HEAD/marco.owx`.
- SHA-256 do OWX original: `54fde32e281df37b79773ca56128ad2526125bc3174717cbb04871750cfd8558`.
- Ontology IRI base: `http://www.semanticweb.org/marco/ontologies/2018/11/marco`.
- Declarações verificadas no arquivo: 163 classes, 12 propriedades de objetos, 14 propriedades de dados, 132 indivíduos.
- Overlay separada: `data/extensao-sintetica-v1.owx`, namespace `https://example.org/isys/fhir-semantic-test/2026/v1#`.
- O processamento é local; nenhuma IRI de indivíduo original é copiada, exibida ou transformada pelo conversor. Uma mudança no hash do original faz a execução falhar explicitamente.

## Extensões de esquema (3 propriedades novas)

| ID | IRI da propriedade | Tipo | Domínio | Alcance | Motivo da criação |
|---|---|---|---|---|---|
| EX-001 | `https://example.org/isys/fhir-semantic-test/2026/v1#tem_ocorrencia_exame` | `ObjectProperty` | `#Evolução` | `R95jloB4mXQPNYJr4PxDfL0` (Exame) | Evitar o uso indevido de `#apresenta`, cujo alcance no original está associado a Diagnóstico/Sintoma |
| EX-002 | `https://example.org/isys/fhir-semantic-test/2026/v1#data_exame` | `DataProperty` | Exame | `xsd:string` | Registrar data da ocorrência de exame explicitamente, sem confundi-la com a data da evolução |
| EX-003 | `https://example.org/isys/fhir-semantic-test/2026/v1#unidade_textual` | `DataProperty` | Exame | `xsd:string` | Registrar unidade literal, sem pressupor normalização UCUM nem reaproveitar erroneamente `unidade_medida`, que no original é `ObjectProperty` |

**Nota temporal:** uma propriedade `xsd:string` para a data é uma escolha de prototipação que permite incluir entradas ambíguas ou inválidas a serem recusadas explicitamente. A saída FHIR `effectiveDateTime` só é emitida quando o literal corresponde ao subconjunto de datas ISO permitido pelo conversor: ano, ano-mês ou data completa. Uma implementação futura pode usar datatypes tipados na origem se a política semântica for definida.

## Elementos reaproveitados SEM extensão de esquema

| IRI original | Uso neste piloto | Restrição |
|---|---|---|
| `#Paciente` | `ClassAssertion` sintética | Nenhum paciente real lido para transformação |
| `#Evolução` | `ClassAssertion` sintética | Não vira `Encounter` |
| `http://webprotege.stanford.edu/R95jloB4mXQPNYJr4PxDfL0` (Exame) | Classe de ocorrência de exame | Não pressupondo equivalência clínica universal a Observation |
| `#possui` | Paciente → Evolução | Compatível com domínio e alcance de declaração original |
| `http://webprotege.stanford.edu/R8Ln57NZOBVImw2EqPktO3f` (`exame`) | Nome literal do exame | Mapeia a `Observation.code.text`, **não** a LOINC |
| `http://webprotege.stanford.edu/RsGwsc6uggNZDQtrRF1fAg` (`resultado`) | Resultado textual ou numérico tipado | Sem inferência de resultado a partir de texto quando o tipo não é numérico |

## Regras de transformação (semântica normativa apenas do protótipo)

1. Para emitir uma `Observation`, o exame deve ter exatamente uma evolução sintética e essa evolução exatamente um paciente sintético. A duplicidade ou ausência impede a transformação.
2. Exige-se o texto do nome do exame. O código é emitido em `code.text`, sem inventar códigos terminológicos.
3. Resultado `xsd:decimal` ou `xsd:integer` → `valueQuantity.value` (serialização decimal exata); resultado `xsd:string` → `valueString`; ausente → `value[x]` ausente; outros tipos → recusa.
4. Unidade textual → `valueQuantity.unit` somente quando existe valor numérico; não emitir `system`/`code` UCUM sem evidência.
5. Data conhecida e válida em ISO (`YYYY`, `YYYY-MM`, `YYYY-MM-DD`) → `effectiveDateTime`, preservando a precisão. Formato ambíguo → recusa; data ausente → campo ausente.
6. `status='unknown'` porque FHIR R4 exige `Observation.status` e a origem de teste não determina status de ciclo de vida. **Não é inferência de resultado clínico ou status `final`.**
7. IDs técnicos de recursos são hashes determinísticos das IRIs fictícias. Não são identificadores clínicos nem identificadores do sistema de origem.
8. `Patient` contém ID técnico apenas. Não são publicados nomes, identificadores reais ou quaisquer indivíduos reais.
9. Uma segunda ocorrência do mesmo tipo de exame continua sendo outra `Observation`. O multiconjunto de ocorrências é preservado.
10. O recurso `Bundle` é `collection`, sem semântica de transação, sem servidor FHIR.

## Decisões deliberadamente não tomadas

- Sem alteração em `#apresenta`, `#paciente_id`, `#local_corpo`, demais axiomas ou indivíduos do arquivo original.
- Sem `Observation.effectiveDateTime` inferido de data de evolução.
- Sem `DiagnosticReport`, `Encounter`, terminologias clínicas (LOINC/UCUM/SNOMED CT) ou perfis brasileiros presumidos.
- Sem diagnósticos clínicos, validação da ontologia com HermiT, inferência OWL ou integração com hospitais.
- Não existe licença de redistribuição presumida para a ontologia original; o ZIP final não a inclui.

## Critérios para avanço à avaliação científica

- Executar validador HL7 oficial (versão e pacote de perfis fixados) nos bundles gerados; registrar ambiente, logs, taxa e denominadores.
- Estender os casos com estratos pré-registrados e oráculos conferidos sem acesso à implementação do conversor.
- Validar interpretações de domínio e as três extensões OWL por pessoa com experiência em FHIR/ontologias.
- Se executar raciocínio OWL, examinar em especial o potencial de novas tipagens inferidas em função dos domínios e alcances existentes.
- Comparar alternativas A/B/C de maneira não enviesada, separando detecção, recusa, correção e custo.
