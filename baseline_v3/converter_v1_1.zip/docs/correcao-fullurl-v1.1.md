# Correção V1.1 — fullUrl para Bundle.collection

- Evidência: 17 erros na validação oficial V2 do Bundle, ausentes nos sete recursos separados.
- Mudança: adiciona a cada `Bundle.entry` um `fullUrl` absoluto consistente com `Resource.resourceType/id`, usando domínio reservado `example.org`.
- Mantido: `Observation.subject.reference` relativo (Patient/id), resolúvel pelo prefixo do fullUrl.
- Não altera: dados de origem, extensão OWL, valores, datas, identificadores ou recusas.
- Duplicação controlada: preserva a mesma identidade e deve ser confrontada com `bdl-7` na execução oficial.
- Os 15 testes anteriores mais teste de referências verificam somente engenharia local.
- Não declarar 0 erros HL7 antes de um novo `OperationOutcome` oficial.
