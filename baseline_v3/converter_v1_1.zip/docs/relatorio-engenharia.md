# Relatório técnico de engenharia: conversor de teste OWL/XML → FHIR R4

**Data:** 25/10/2026. **Estado:** implementação e testes locais executados. Não constitui resultado do artigo científico.

## Escopo efetivamente executado

Foi analisado o esquema do arquivo OWL/XML original com SHA-256 fixado e utilizada uma extensão OWL/XML **exclusivamente sintética**, descrita em `docs/registro-extensoes.md`. A extensão foi processada juntamente com as declarações do esquema original, sem alteração do arquivo-fonte e sem copiar dados de indivíduos originais. O novo código é um protótipo de transformação determinística; não aplica inferência OWL ou NLP.

A execução gera um `Bundle` FHIR R4 (coleção) de recursos `Patient` e `Observation`, uma tabela de rastreamento, um registro de recusas e as respostas comparadas das consultas de competência. O resultado foi conferido com oráculo de casos mantido em arquivo distinto do algoritmo.

## Resultados de engenharia do demonstrador sintético

| Indicador | Valor | Natureza |
|---|---:|---|
| Ocorrências fictícias da extensão | 11 | Casos de software (não pacientes ou amostras clínicas) |
| Convertidas em `Observation` | 5 | 5 de 11; **não é cobertura populacional da ontologia original** |
| Recusadas | 6 | 1 sem paciente, 1 com pacientes múltiplos, 1 sem nome, 1 data ambígua, 1 resultado de tipo não suportado e 1 com dois resultados conflitantes |
| Recursos `Patient` emitidos | 2 | Apenas indivíduos sintéticos referenciados pelas 5 observações aceitas |
| Inconsistências com oráculo separado | 0 | Oráculo técnico produzido para os cenários sintéticos; não validado por especialista externo |
| Testes de regressão | 15 aprovados | Execução local com `unittest` |
| Consultas Q01–Q05 sobre ocorrências aceitas | 5/5 equivalentes | Não cobre 6 recusas; Q06 documenta exclusões |
| Mutações de engenharia detectadas pelo comparador semântico | 7/7 | Variações construídas para testar componentes; não representativas da realidade clínica |
| Mutações sinalizadas pela checagem estrutural local limitada | 1/7 | **NÃO É validador HL7**, comparação limitada |
| Hash do ZIP original antes e depois | Igual | Sem alteração da fonte |

### Interpretação de mutações

Mutações sintéticas introduzidas: troca de valor numérico, troca de resultados entre exames, alteração de data, troca de paciente para outro paciente existente, supressão de resultado, adição de valor ausente na origem e duplicação de ocorrência. As seis primeiras preservam formato aparentemente coerente para a checagem estrutural local e foram detectadas pelo oráculo semântico. A duplicação foi detectada pelos dois mecanismos. Esse resultado **não mede** recall, sensibilidade ou superioridade de uma condição experimental FHIR oficial: é apenas verificação interna de software.

### Consultas e domínio de aplicação

- Q01–Q04: relações paciente/exame, resultado, data, unidades explícitas, com multiconjuntos e precisão preservada.
- Q05: intervalo de março/2026 com estados `IN`, `OUT`, `INDETERMINATE` e `UNKNOWN_DATE` para evitar equiparar data incompleta a negativa.
- Q06: ocorrências não representadas e suas razões. Não permite alegar preservação total quando há recusa.

### Limitações e próximos critérios

- `status: unknown` é válido na lista de códigos FHIR R4 e evita fabricar `final` onde não há informação de ciclo de vida.
- Não foi executado o validador oficial HL7, nem conformidade com um perfil clínico/guia de implementação específico. A checagem local verifica somente algumas condições necessárias, não suficientes.
- Não foi executado o HermiT ou outra verificação de consistência lógica.
- O teste do conversor usa uma ontologia sintética que **reutiliza o esquema** da ontologia real; não transforma instâncias clínicas originais.
- O oráculo foi separado do algoritmo, porém ainda não recebeu revisão externa independente.
- As mutações compartilham uma base de casos e não são observações independentes; nenhuma estatística inferencial pode ser calculada legitimamente com base nelas.
- Ainda falta executar os três braços A/B/C no desenho científico completo e registrar custo/latência/erros em uma base de avaliação independente.

Fontes técnicas: https://hl7.org/fhir/R4/observation.html , https://hl7.org/fhir/R4/valueset-observation-status.html e https://hl7.org/fhir/R4/datatypes.html.
