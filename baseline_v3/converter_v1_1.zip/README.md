# iSys — Conversor experimental OWL/XML → HL7 FHIR R4 (teste-v1)

Este pacote executa um **conversor real de software** sobre uma **extensão de teste exclusivamente sintética** que referencia classes e propriedades do esquema da ontologia oncológica original. **Não modifica o arquivo original**, não transforma indivíduos reais e não contém seu ZIP.

## Arquivos principais

- `src/isys_converter/schema.py`: leitura segura, confirmação de SHA-256 original e parsing do overlay.
- `src/isys_converter/generate_overlay.py`: geração reproduzível da extensão OWL/XML sintética.
- `src/isys_converter/transform.py`: conversor determinístico para FHIR R4 v4.0.1, com recusa e rastreabilidade.
- `src/isys_converter/competency.py`: consultas Q01–Q06 e comparação origem/destino.
- `src/isys_converter/audit.py`: verificações locais limitadas, confronto com oráculo separado, mutações de engenharia.
- `src/isys_converter/cli.py`: executor que registra artefatos, hash e não modificação do original.
- `data/extensao-sintetica-v1.owx`: arquivo novo versionado com três propriedades extras e onze ocorrências inventadas.
- `data/oraculo-independente.json`: expectativas especificadas separadamente do conversor.
- `docs/registro-extensoes.md`: decisões e a lista exata das alterações de esquema.
- `docs/relatorio-engenharia.md`: resultados, alcance e limites.
- `tests/`: testes de regressão.
- `outputs/`: saídas verificáveis já obtidas, geradas unicamente com dados fictícios.

## Execução reproduzível (Python 3.10+; somente biblioteca padrão)

O arquivo `ontologia-cbms-ontologies.owx.zip` original deve estar disponível no computador que executar. Ele é **lido**, não escrito. O algoritmo verifica que o `.owx` dentro do ZIP tem SHA-256 `54fde32e281df37b79773ca56128ad2526125bc3174717cbb04871750cfd8558` e falha se for outra versão.

No diretório raiz deste projeto:

```bash
PYTHONPATH=src python -m isys_converter.cli \
  --base-zip /caminho/ontologia-cbms-ontologies.owx.zip \
  --overlay data/extensao-sintetica-v1.owx \
  --oracle data/oraculo-independente.json \
  --output outputs
ISYS_BASE_ZIP=/caminho/ontologia-cbms-ontologies.owx.zip python -m unittest discover -s tests -v
```

No Windows PowerShell:

```powershell
$env:PYTHONPATH = "src"
$env:ISYS_BASE_ZIP = "C:\caminho\ontologia-cbms-ontologies.owx.zip"
python -m isys_converter.cli --base-zip $env:ISYS_BASE_ZIP --overlay "data\extensao-sintetica-v1.owx" --oracle "data\oraculo-independente.json" --output "outputs"
python -m unittest discover -s tests -v
```

Os testes tentam localizar o ZIP original na pasta pai do projeto ou no caminho do ambiente de desenvolvimento. Também aceitam explicitamente `ISYS_BASE_ZIP` (recomendado). Sem o ZIP, os testes que dependem do original são marcados como *skipped*. O executor CLI exige o ZIP e nunca gera resultados em silêncio sem a fonte correta.

## O que NÃO está validado

Não há conformidade oficial confirmada do HL7 FHIR, execução do HL7 Validator, validação de perfis, reasoner OWL, avaliação clínica, tradução para terminologias clínicas ou experimento científico quantitativo. A implementação prova a execução técnica de um pipeline controlado, não sua adequação a um ambiente hospitalar. Consultas Q01–Q05 avaliam somente casos aceitos, enquanto Q06 e o relatório preservam o denominador total.

## Alteração V1.1 (2026-10-25)
Cada `Bundle.entry` do tipo `collection` recebe `fullUrl=https://example.org/fhir/<ResourceType>/<id>`, mantendo referências relativas resolúveis. Correção demandada por 17 erros de Bundle no HL7 Validator V2. **A validação oficial V1.1 ainda exige nova execução.** Nenhuma ontologia original foi modificada.
