"""Regression tests: source integrity, real schema binding, exact value preservation,
refusal behavior, instance occurrence fidelity, mutation checks, independent oracle.
"""
import sys,unittest,hashlib,json,copy,tempfile,os
from pathlib import Path
from decimal import Decimal
from xml.etree import ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from isys_converter.schema import *
from isys_converter.transform import convert, decimal_json, date_check
from isys_converter.audit import compare_oracle,local_structure_check,mutations_and_checks
from isys_converter.competency import queries, _interval
from datetime import date
from isys_converter.generate_overlay import generate

class TestSyntheticOntologyConverter(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.basezip=Path(os.environ['ISYS_BASE_ZIP']) if 'ISYS_BASE_ZIP' in os.environ else Path(__file__).resolve().parents[2]/'ontologia-cbms-ontologies.owx.zip'
        if not cls.basezip.exists():
            cls.basezip=Path('/mnt/data/ontologia-cbms-ontologies.owx.zip')
        if not cls.basezip.exists():
            raise unittest.SkipTest('Original ZIP absent. Pass it to the runnable CLI. No substitute used.')
        cls.original_sha=hashlib.sha256(cls.basezip.read_bytes()).hexdigest()
        cls.base=verify_base(cls.basezip)
        cls.overlay=ROOT/'data'/'extensao-sintetica-v1.owx'
        cls.g=SyntheticGraph(cls.overlay,cls.base['declared_uris'])
        cls.bundle,cls.trace,cls.rejected,cls.report=convert(cls.g)
        cls.oracle=json.loads((ROOT/'data'/'oraculo-independente.json').read_text())

    def test_original_unmodified(self):
        self.assertEqual(self.original_sha,hashlib.sha256(self.basezip.read_bytes()).hexdigest())
        self.assertEqual(self.base['sha256'],BASE_HASH)

    def test_schema_fingerprint_and_declarations(self):
        self.assertEqual(self.base['declarations']['Class'],163)
        self.assertEqual(self.base['declarations']['ObjectProperty'],12)
        self.assertEqual(self.base['declarations']['DataProperty'],14)

    def test_synthetic_extension_is_separate_and_versioned(self):
        overlay=ET.parse(self.overlay).getroot()
        self.assertEqual(overlay.get('ontologyIRI'),TEST.rstrip('#'))
        self.assertTrue(all(i.startswith(TEST) for i in self.g.individuals))
        self.assertEqual(len(self.g.nodes(EXAM)),11)

    def test_determinism(self):
        b2,t2,r2,stats2=convert(self.g)
        self.assertEqual(decimal_json(self.bundle),decimal_json(b2))
        self.assertEqual(self.trace,t2)
        self.assertEqual(self.rejected,r2)

    def test_completeness_and_refusal_accounted_for(self):
        self.assertEqual(self.report['exams_in_overlay'],11)
        self.assertEqual(self.report['emitted_observations'],5)
        self.assertEqual(self.report['rejected_exams'],6)
        self.assertEqual(self.report['emitted_observations']+self.report['rejected_exams'],11)

    def test_independent_expected_cases(self):
        self.assertEqual([],compare_oracle(self.bundle,self.trace,self.rejected,self.oracle))

    def test_no_unsupported_fhir_claims(self):
        self.assertEqual([],local_structure_check(self.bundle))
        obs=[e['resource'] for e in self.bundle['entry'] if e['resource']['resourceType']=='Observation']
        self.assertEqual(len(obs),5)
        self.assertTrue(all(o['status']=='unknown' for o in obs))
        self.assertTrue(all('coding' not in o['code'] for o in obs))
        self.assertTrue(all('encounter' not in o for o in obs))
        self.assertFalse(any(e['resource']['resourceType'] in ('DiagnosticReport','Encounter') for e in self.bundle['entry']))

    def test_bundle_fullurls_resolvable_and_distinct(self):
        entries=self.bundle['entry']
        urls=[x['fullUrl'] for x in entries]
        self.assertEqual(len(urls),len(set(urls)))
        self.assertTrue(all(e['fullUrl']==f'https://example.org/fhir/{e["resource"]["resourceType"]}/{e["resource"]["id"]}' for e in entries))
        by_url={e['fullUrl']:e['resource'] for e in entries}
        for e in entries:
            r=e['resource']
            if r['resourceType']=='Observation':
                self.assertIn('https://example.org/fhir/'+r['subject']['reference'],by_url)
                self.assertEqual(by_url['https://example.org/fhir/'+r['subject']['reference']]['resourceType'],'Patient')

    def test_decimal_json_value_preservation(self):
        out=decimal_json(self.bundle)
        # Verify bytes contain a JSON decimal with trailing source precision; not scientific numeric reformatting.
        self.assertIn('25.20',out)
        recovered=json.loads(out,parse_float=Decimal)
        quantity=[e['resource']['valueQuantity'] for e in recovered['entry'] if e['resource'].get('resourceType')=='Observation' and e['resource'].get('code',{}).get('text')=='CEA']
        self.assertEqual([Decimal('25.20')]*2,[q['value'] for q in quantity])
        self.assertEqual([Decimal('25.20').as_tuple().exponent]*2,[q['value'].as_tuple().exponent for q in quantity])

    def test_date_validation(self):
        for good in ('2026','2026-03','2026-03-15','2024-02-29'):
            self.assertTrue(date_check(good),good)
        for bad in ('2026-02-30','10/11/2026','2026-13','0000','2025-02-29','2026-03-11T08:00'):
            self.assertFalse(date_check(bad),bad)

    def test_no_inferred_units(self):
        text=decimal_json(self.bundle)
        self.assertNotIn('unitsofmeasure.org',text)
        self.assertNotIn('loinc.org',text)

    def test_mutations_detected(self):
        findings=mutations_and_checks(self.bundle,self.trace,self.rejected,self.oracle)
        self.assertEqual([],findings['baseline_oracle_discrepancies'])
        self.assertTrue(all(x['semantic_check_flags'] for x in findings['mutations']))
        self.assertGreater(len(findings['mutations']),5)
        self.assertFalse(next(x['local_check_flags'] for x in findings['mutations'] if x['mutation']=='change_numeric_value'))

    def test_competency_questions_and_three_valued_dates(self):
        q=queries(self.g,self.bundle,self.trace,self.rejected)
        self.assertTrue(all(x["exact_normalized_multiset_equivalence"] for x in q["comparisons"][:5]))
        self.assertEqual(6,q["comparisons"][-1]["refusal_count"])
        self.assertEqual("IN",_interval("2026-03",date(2026,3,1),date(2026,3,31)))
        self.assertEqual("INDETERMINATE",_interval("2026",date(2026,3,1),date(2026,3,31)))
        self.assertEqual("UNKNOWN_DATE",_interval(None,date(2026,3,1),date(2026,3,31)))

    def test_reject_nonmatching_original_hash(self):
        with tempfile.TemporaryDirectory() as td:
            import zipfile
            new=Path(td)/'different.zip'
            with zipfile.ZipFile(new,'w') as z:z.writestr('file.owx','<bad/>')
            with self.assertRaises(ValueError):verify_base(new)

    def test_reject_non_synthetic_source_assertions(self):
        with tempfile.TemporaryDirectory() as td:
            original=self.overlay.read_text()
            modified=original.replace(TEST+'ex01',BASE+'#actualOriginalIndividual',1)
            path=Path(td)/'intrusive.owx';path.write_text(modified)
            with self.assertRaises(ValueError):SyntheticGraph(path,self.base['declared_uris'])

    def test_generated_overlay_exactly_reproducible(self):
        with tempfile.TemporaryDirectory() as td:
            alt=Path(td)/'fixture.owx';generate(alt)
            self.assertEqual(alt.read_bytes(),self.overlay.read_bytes())

if __name__=='__main__':unittest.main()
